package com.domian;

public class DomainObject {
	private String id;
	public DomainObject(){};
	public DomainObject(String id) {
		this.id = id;
	}
	public String getId() {
		return this.id;
	}

}
